from PyQt5.QtCore import Qt, pyqtSignal, QObject
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtWidgets as QtGui

from PyQt5.QtGui import QImage, QPixmap
from PyQt5.uic import loadUi
from PyQt5.QtCore import pyqtSlot, QTimer, QDate, Qt
from PyQt5.QtWidgets import QDialog,QMessageBox

import sys
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

from GUI_1 import Ui_MainWindow

import numpy as np
import datetime
import cv2
import os
import csv
import pandas as pd



class Window(QMainWindow, Ui_MainWindow):
    def __init__(self, parent = None):
        super().__init__(parent)
        self.setupUi(self)

        #Update time
        now = QDate.currentDate()
        current_date = now.toString('ddd dd MMMM yyyy')
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        self.Display_date.setText(current_date)
        self.Display_time.setText(current_time)

        self.Btn_Checkin.clicked.connect(self.CaptureImage)
        self.Btn_Start.clicked.connect(self.StartCamera)
        self.Btn_print.clicked.connect(self.exportExcel)

        self.Worker1 = Worker1()
    def StartCamera(self):
        self.Worker1.start()
        self.Worker1.ImageUpdate.connect(self.ImageUpdateSlot)
    
    def CaptureImage(self):
        if self.Worker1.isRunning():
            ret, frame = self.Worker1.capture_frame()
            cv2.imwrite("D:\DO_AN_HOC_KY_2_2023_2024\GUI_GIAO_DIEN\\TU_DINH.png", frame)

    def ImageUpdateSlot(self, Image):
        self.Camera.setPixmap(QPixmap.fromImage(Image))

    def CancelFeed(self):
        self.Worker1.stop()

    def keyPressEvent(self, event):
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        if event.key() == Qt.Key_1: # Kiem tra gia tri tu output của Model
            self.Display_name.setText('Ho Dang Tu')
            self.Display_time_3.setText('20146150')
            self.Display_timeckin.setText(current_time)
        elif event.key() == Qt.Key_2:
            self.Display_name.setText('Nguyen Tan Dinh')
            self.Display_time_3.setText('2114560')
            self.Display_timeckin.setText(current_time)

    def exportExcel(self):
        # Lấy dữ liệu từ các trường
        name = self.Display_name.text()
        student_id = self.Display_time_3.text()
        time_checkin = self.Display_timeckin.text()

        # Tạo DataFrame từ dữ liệu
        new_data = {
            "Name": [name],
            "ID Student": [student_id],
            "Time Checkin": [time_checkin]
        }
        new_df = pd.DataFrame(new_data)

        # Xuất DataFrame thành file Excel
        file_path = "D:\DO_AN_HOC_KY_2_2023_2024\GUI_GIAO_DIEN\checkin_data.xlsx"
        if os.path.exists(file_path):
            existing_df = pd.read_excel(file_path)
            updated_df = pd.concat([existing_df, new_df], ignore_index=True)
        else:
            updated_df = new_df

        updated_df.to_excel(file_path, index=False)

        

class Worker1(QThread):
    ImageUpdate = pyqtSignal(QImage)

    def run(self):
        self.ThreadActive = True
        self.Capture = cv2.VideoCapture(0)
        while self.ThreadActive:
            ret, frame = self.Capture.read()
            if ret:
                Image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                FlippedImage = cv2.flip(Image, 1)
                ConvertToQtFormat = QImage(FlippedImage.data, FlippedImage.shape[1], FlippedImage.shape[0], QImage.Format_RGB888)
                Pic = ConvertToQtFormat.scaled(500, 375, Qt.KeepAspectRatio)
                self.ImageUpdate.emit(Pic)
                

    def capture_frame(self):
        if self.Capture.isOpened():
            ret, frame = self.Capture.read()
            return ret, frame
        return False, None

    def stop(self):
        self.ThreadActive = False
        self.quit()
        self.Capture.release()


if __name__ == '__main__':
    app = QApplication([])
    window = Window()
    window.show()
    app.exec_()